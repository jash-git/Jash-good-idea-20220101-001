 
![PySimpleGUI_Debugger_Logo](https://user-images.githubusercontent.com/13696193/58375496-38cbb280-7f22-11e9-99b8-286fe1fa41b5.png)

## is no more.... but `imwatching` you now  the same thing
        
               
# Project renamed to:        
# `imwatchingyou`     

So head over to that project page.  
https://github.com/PySimpleGUI/imwatchingyou

----------------------

To install it:

`pip install imwatchingyou`

To use it, check out the Demo Program on the project's page.

----------------------

About the creepy title

Don't worry, I'm not watching YOU...

#### I'm not watching you, YOU are watching YOUR CODE

