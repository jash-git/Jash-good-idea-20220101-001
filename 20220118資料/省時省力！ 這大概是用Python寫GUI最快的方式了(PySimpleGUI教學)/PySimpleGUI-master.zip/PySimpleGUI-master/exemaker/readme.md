# PySimpleGUI-exemaker

## Introduction
This package contains a GUI front-end to PyInstaller.  Use this tool to create EXE files from your python programs

  ![snag-0086](https://user-images.githubusercontent.com/13696193/46968655-c2103200-d081-11e8-926f-d5f977e726f3.jpg)


## Installing

When you install PySimpleGUI-exemaker, it will install the other components that it requires. To install, on windows, type this into a command prompt:

    pip install pysimplegui-exemaker


## PySimpleGUI Project

This program was built as a sample application of the PySimpleGUI GUI Framework.


## Running the program

After your pip install, type this into your command prompt:

  python -m pysimplegui-exemaker.pysimplegui-exemaker
