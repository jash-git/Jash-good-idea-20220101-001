# emotion-detection

This repository consists of all the files for the emotion detection system and i have also added the code to run the script in flask server.

The dataset can be downloaded from [this link](https://drive.google.com/drive/folders/1bCFKTkmItIZl73YNUq5QXppLpIdmTgUv?usp=sharing).
