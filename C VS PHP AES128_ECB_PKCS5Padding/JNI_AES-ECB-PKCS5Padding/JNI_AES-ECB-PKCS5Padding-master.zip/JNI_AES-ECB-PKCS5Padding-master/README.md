# JNI_AES-ECB-PKCS5Padding
JNI方式实现的AES/ECB/PKCS5Padding 加密 和java配套使用
由https://github.com/BruceWind/AESJniEncrypt
精简而来。只想使用AES-ECB-PKCS5Padding方式的加密。其他都用不上。
