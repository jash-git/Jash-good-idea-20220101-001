//
// Created by yekangqi on 2016/11/8.
//

#ifndef JNIAESDEMO_AES_LIB_H
#define JNIAESDEMO_AES_LIB_H
jstring charToJstring(JNIEnv* envPtr, char *src);
#endif //JNIAESDEMO_AES_LIB_H
