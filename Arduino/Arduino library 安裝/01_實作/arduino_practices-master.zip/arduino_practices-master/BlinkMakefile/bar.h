#ifndef bar_h
#define bar_h


class ClassBar{
private:
	int delayDuration;
public:
	ClassBar();
	int getDelayDuration();
};

#endif

