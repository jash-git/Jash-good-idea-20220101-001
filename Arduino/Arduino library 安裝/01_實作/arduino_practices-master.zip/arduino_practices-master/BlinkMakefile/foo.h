#ifndef foo_h
#define foo_h

#ifdef __cplusplus
extern "C"{
#endif

int delayDuration();

#ifdef __cplusplus
}
#endif

#endif

