int delayDuration()
{
	return 1000;
}

